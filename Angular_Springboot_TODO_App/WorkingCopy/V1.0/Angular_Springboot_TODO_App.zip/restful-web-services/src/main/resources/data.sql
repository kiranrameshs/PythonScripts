insert into todo(id,username,description,target_date,done)
values(1001,'kiran','Learn JPA',sysdate(),false);

insert into todo(id,username,description,target_date,done)
values(1002,'kiran','Learn Hibernate',sysdate(),false);